<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Employee Registration</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        .container {
            width: 450px;
            margin: 40px auto;
            padding: 25px;
            background-color: white;
            border-radius: 10px;
        }

        h2 {
            text-align: center;
        }

        label {
            display: block;
            margin-top: 10px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            margin-top: 20px;
            cursor: pointer;
        }
    </style>
</head>

<body>

<div class="container">

    <h2>Employee Registration Form</h2>

    <form action="EmployeeServlet" method="post">

        <label>Employee ID:</label>
        <input type="number" name="emp_id" required>

        <label>Employee Name:</label>
        <input type="text" name="emp_name" required>

        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Phone Number:</label>
        <input type="text" name="phone" required>

        <label>Department:</label>
        <input type="text" name="department" required>

        <label>Designation:</label>
        <input type="text" name="designation" required>

        <label>Salary:</label>
        <input type="number" step="0.01" name="salary" required>

        <input type="submit" value="Submit">

    </form>

</div>

</body>
</html>