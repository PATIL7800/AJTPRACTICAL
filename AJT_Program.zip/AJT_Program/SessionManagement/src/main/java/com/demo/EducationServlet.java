package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/EducationServlet")
public class EducationServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        String degree = request.getParameter("degree");
        String university = request.getParameter("university");

        HttpSession session = request.getSession();

        session.setAttribute("degree", degree);
        session.setAttribute("university", university);

        String name = (String) session.getAttribute("name");
        String age = (String) session.getAttribute("age");
        String email = (String) session.getAttribute("email");
        String phone = (String) session.getAttribute("phone");

        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<body>");

        out.println("<h2>All Student Details</h2>");

        out.println("<p>Name: " + name + "</p>");
        out.println("<p>Age: " + age + "</p>");
        out.println("<p>Email: " + email + "</p>");
        out.println("<p>Phone: " + phone + "</p>");
        out.println("<p>Degree: " + degree + "</p>");
        out.println("<p>University: " + university + "</p>");

        out.println("</body>");
        out.println("</html>");
    }
}