import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
public class JDBCConnection {

    public static void main(String[] args) {

        try {
            // 1. MySQL Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2. Database Connection
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/mydb",
                    "root",
                    "mysql@123"
                );

            System.out.println("Database connected successfully");

          
            // 4. Insert Data
            Statement stmt = con.createStatement();

            String sql = "INSERT INTO student (id, name, age, city) "
                       + "VALUES (5, 'Om', 20, 'Kolhapur')";

            int result = stmt.executeUpdate(sql);
            

            if (result > 0) {
                System.out.println("Data inserted successfully");
            }
         // DISPLAY CODE — YAHAN PASTE KARO
            String query = "SELECT * FROM student";

            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Age: " + rs.getInt("age"));
                System.out.println("City: " + rs.getString("city"));
                System.out.println("-------------------");
            }
            // 5. Check Result
            if (result > 0) {
                System.out.println("Data inserted successfully");
            }

            // 6. Close connection
            stmt.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}