<!DOCTYPE html>
<html>
<head>
    <title>Pass or Fail</title>
</head>
<body>

<h2>Pass or Fail</h2>

<form method="post">
    Enter Marks:
    <input type="number" name="marks" min="0" max="100" required>
    <input type="submit" value="Check">
</form>

<%
String marks = request.getParameter("marks");

if (marks != null && !marks.isEmpty()) {
    int m = Integer.parseInt(marks);
%>

<h3>Entered Marks: <%= m %></h3>

<%
    if (m > 40) {
%>
        <h3>Result: Pass</h3>
<%
    } else {
%>
        <h3>Result: Fail</h3>
<%
    }
}
%>

</body>
</html>