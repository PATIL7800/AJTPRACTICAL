<!DOCTYPE html>
<html>
<head>
    <title>Even or Odd</title>
</head>
<body>

<h2>Even or Odd Number</h2>

<form method="post">
    Enter Number:
    <input type="number" name="num" required>
    <input type="submit" value="Check">
</form>

<%
String num = request.getParameter("num");

if (num != null && !num.equals("")) {
    int n = Integer.parseInt(num);

    if (n % 2 == 0) {
%>
        <h3>Number: <%= n %></h3>
        <h3>Number is Even</h3>
<%
    } else {
%>
        <h3>Number: <%= n %></h3>
        <h3>Number is Odd</h3>
<%
    }
}
%>

</body>
</html>