<!DOCTYPE html>
<html>
<head>
    <title>Positive or Negative</title>
</head>
<body>

<h2>Positive or Negative</h2>

<form method="post">
    Enter Number:
    <input type="number" name="num" required>
    <input type="submit" value="Check">
</form>

<%
String num = request.getParameter("num");

if (num != null && !num.isEmpty()) {
    int n = Integer.parseInt(num);
%>

<h3>Entered Number: <%= n %></h3>

<%
    if (n > 0) {
%>
        <h3>Number is Positive</h3>
<%
    } else if (n < 0) {
%>
        <h3>Number is Negative</h3>
<%
    } else {
%>
        <h3>Number is Zero</h3>
<%
    }
}
%>

</body>
</html>