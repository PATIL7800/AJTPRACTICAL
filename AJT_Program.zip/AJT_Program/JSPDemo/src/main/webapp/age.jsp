<!DOCTYPE html>
<html>
<head>
    <title>Age Checker</title>
</head>
<body>

<h2>Age Checker</h2>

<form method="post">
    Enter Age:
    <input type="number" name="age" required>
    <input type="submit" value="Check">
</form>

<%
String age = request.getParameter("age");

if (age != null && !age.equals("")) {
    int a = Integer.parseInt(age);

    if (a >= 18) {
%>
        <h3>Age: <%= a %></h3>
        <h3>Eligible for Voting</h3>
<%
    } else {
%>
        <h3>Age: <%= a %></h3>
        <h3>Not Eligible for Voting</h3>
<%
    }
}
%>

</body>
</html>