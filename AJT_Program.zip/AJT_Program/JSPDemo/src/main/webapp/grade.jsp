<!DOCTYPE html>
<html>
<head>
    <title>Grade Calculator</title>
</head>
<body>

<h2>Grade Calculator</h2>

<form method="post">
    Enter Marks:
    <input type="number" name="marks" min="0" max="100" required>
    <input type="submit" value="Calculate Grade">
</form>

<%
String marks = request.getParameter("marks");

if (marks != null && !marks.isEmpty()) {
    int m = Integer.parseInt(marks);
%>

<h3>Entered Marks: <%= m %></h3>

<%
    if (m >= 90 && m <= 100) {
%>
        <h3>Grade: A</h3>
<%
    } else if (m >= 75 && m <= 89) {
%>
        <h3>Grade: B</h3>
<%
    } else if (m >= 60 && m <= 74) {
%>
        <h3>Grade: C</h3>
<%
    } else {
%>
        <h3>Grade: Below C</h3>
<%
    }
}
%>

</body>
</html>