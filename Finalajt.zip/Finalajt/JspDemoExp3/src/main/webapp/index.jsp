<html>
<body>

    <h2>User Information Form</h2>

    <form action="welcome.jsp" method="POST">

        Username:
        <input type="text" name="username">
        <br><br>

        Age:
        <input type="text" name="userage">
        <br><br>

        <input type="submit" value="Submit">

    </form>

</body>
</html>