<html>
<body>

    <%
        String name = request.getParameter("username");

        String ageStr = request.getParameter("userage");

        int age = Integer.parseInt(ageStr);
    %>

    <h2>Welcome <%= name %></h2>

    <%
        if(age >= 18)
        {
    %>

        <h3>You are an Adult.</h3>

    <%
        }
        else
        {
    %>

        <h3>You are a Minor.</h3>

    <%
        }
    %>

    <p>Your Age is: <%= age %></p>

</body>
</html>