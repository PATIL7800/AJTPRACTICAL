
<!DOCTYPE html>
<html>
<head>
    <title>Student Details</title>
</head>
<body>

    <h2>Student Details</h2>

    Name: ${sessionScope.name}
    <br><br>

    Age: ${sessionScope.age}
    <br><br>

    Email: ${sessionScope.email}
    <br><br>

    Mobile: ${sessionScope.mobile}
    <br><br>

    Course: ${sessionScope.course}
    <br><br>

    College: ${sessionScope.college}
    <br><br>

</body>
</html>
