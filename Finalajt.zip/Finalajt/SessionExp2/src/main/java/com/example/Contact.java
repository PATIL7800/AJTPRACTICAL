
package com.example;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/Contact")
public class Contact extends HttpServlet {

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        // Get existing session
        HttpSession session = request.getSession();

        // Get contact details
        String email = request.getParameter("email");
        String mobile = request.getParameter("mobile");

        // Store data in session
        session.setAttribute("email", email);
        session.setAttribute("mobile", mobile);

        // Redirect to next page
        response.sendRedirect("Education.html");
    }
}
