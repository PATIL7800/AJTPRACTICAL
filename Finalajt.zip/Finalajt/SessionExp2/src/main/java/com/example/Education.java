
package com.example;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/Education")
public class Education extends HttpServlet {

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        // Get existing session
        HttpSession session = request.getSession();

        // Get education details
        String course = request.getParameter("course");
        String college = request.getParameter("college");

        // Store data in session
        session.setAttribute("course", course);
        session.setAttribute("college", college);

        // Forward to result.jsp
        request.getRequestDispatcher("result.jsp")
               .forward(request, response);
    }
}
