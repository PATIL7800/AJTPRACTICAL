
package com.example;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/personal")
public class Personal extends HttpServlet {

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        // Create session
        HttpSession session = request.getSession();

        // Get data from form
        String name = request.getParameter("name");
        String age = request.getParameter("age");

        // Store data in session
        session.setAttribute("name", name);
        session.setAttribute("age", age);

        // Redirect to next page
        response.sendRedirect("Contact.html");
    }
}
