package com.example;

import java.io.IOException;
import java.util.Properties;

import javax.mail.*;
import javax.mail.internet.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/sendEmail")
public class SendEmailServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        // Get data from HTML form
        String to = request.getParameter("to");
        String subject = request.getParameter("subject");
        String body = request.getParameter("body");

        // Sender email
        final String username = "bitesfilm097@gmail.com";

        // Gmail App Password
        final String password = "ijdkznaldqlzveth";

        // SMTP settings
        Properties props = new Properties();

        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        // Create mail session
        Session session = Session.getInstance(props,
                new Authenticator() {

                    protected PasswordAuthentication
                    getPasswordAuthentication() {

                        return new PasswordAuthentication(
                                username, password);
                    }
                });

        try {

            // Create email message
            Message message = new MimeMessage(session);

            // Sender
            message.setFrom(
                    new InternetAddress(username));

            // Receiver
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(to));

            // Subject
            message.setSubject(subject);

            // Message body
            message.setText(body);

            // Send email
            Transport.send(message);

            response.getWriter().println(
                    "Email sent successfully!");

        } catch (MessagingException e) {

            e.printStackTrace();

            response.getWriter().println(
                    "Error sending email: "
                    + e.getMessage());
        }
    }
}