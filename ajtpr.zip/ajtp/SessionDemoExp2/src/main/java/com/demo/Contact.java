package com.demo;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/Contact")
public class Contact extends HttpServlet {

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws IOException {

        HttpSession session = request.getSession();

        String email = request.getParameter("email");
        String mobile = request.getParameter("mobile");

        session.setAttribute("email", email);
        session.setAttribute("mobile", mobile);

        response.sendRedirect("Education.html");
    }
}