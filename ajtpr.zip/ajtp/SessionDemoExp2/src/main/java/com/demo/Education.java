package com.demo;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/Education")
public class Education extends HttpServlet {

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String course = request.getParameter("course");
        String college = request.getParameter("college");

        session.setAttribute("course", course);
        session.setAttribute("college", college);

        request.getRequestDispatcher("result.jsp")
               .forward(request, response);
    }
}