package com.demo;

import java.io.IOException;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/personal")
public class Personal extends HttpServlet {

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws IOException {

        HttpSession session = request.getSession();

        String name = request.getParameter("name");
        String age = request.getParameter("age");

        session.setAttribute("name", name);
        session.setAttribute("age", age);

        response.sendRedirect("Contact.html");
    }
}