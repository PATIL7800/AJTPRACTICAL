<html>
<body>

    <h2>Student Details</h2>

    Name: ${sessionScope.name}<br>
    Age: ${sessionScope.age}<br>
    Email: ${sessionScope.email}<br>
    Mobile: ${sessionScope.mobile}<br>
    Course: ${sessionScope.course}<br>
    College: ${sessionScope.college}<br>

</body>
</html>