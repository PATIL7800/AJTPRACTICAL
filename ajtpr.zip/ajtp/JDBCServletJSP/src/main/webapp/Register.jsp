
<html>
<head>
    <title>Student Registration</title>
</head>
<body>

    <h2>Student Registration Form</h2>

    <form action="RegisterServlet" method="post">

        ID:
        <input type="text" name="id">
        <br><br>

        Name:
        <input type="text" name="name">
        <br><br>

        Email:
        <input type="email" name="email">
        <br><br>

        <input type="submit" value="Register">

    </form>

</body>
</html>
